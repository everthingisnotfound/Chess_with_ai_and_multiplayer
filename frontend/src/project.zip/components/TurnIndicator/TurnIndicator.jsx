export default function TurnIndicator({ turn }) {
  return (
    <div
      style={{
        marginTop: "16px",
        textAlign: "center",
        fontSize: "18px",
        fontWeight: "bold",
        color: "#2e7d32",
        animation: "pop 0.6s ease"
      }}
    >
      🎉 {turn === "w" ? "White to move" : "Black to move"}
    </div>
  );
}
