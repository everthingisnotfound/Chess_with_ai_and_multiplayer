import "./moveHistory.css";

export default function MoveHistory({ moves }) {
  return (
    <div className="move-history">
      <h3>Move History</h3>
      <ol>
        {moves.map((move, i) => (
          <li key={i}>
            {move.color === "w" ? "White" : "Black"}: {move.san}
          </li>
        ))}
      </ol>
    </div>
  );
}
