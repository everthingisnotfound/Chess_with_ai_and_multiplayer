import Board from "./components/Board/Board";
import PlayerInfo from "./components/PlayerInfo/PlayerInfo";
import MoveHistory from "./components/MoveHistory/MoveHistory";
import Timer from "./components/Timer/Timer";
import TurnIndicator from "./components/TurnIndicator/TurnIndicator";
import useChessGame from "./hooks/useChessGame";

export default function App() {
  const {
    board,
    moves,
    selectedSquare,
    legalMoves,
    handleSquareClick,
    turn,
    whiteTime,
    blackTime,
    gameStatus
  } = useChessGame();

  return (
    <div style={{ padding: "20px" }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          maxWidth: "520px",
          margin: "0 auto"
        }}
      >
        <PlayerInfo name={`White (${whiteTime}s)`} />
        <PlayerInfo name={`Black (${blackTime}s)`} />
      </div>

      <div
        style={{
          display: "flex",
          gap: "30px",
          marginTop: "20px",
          flexWrap: "wrap",
          justifyContent: "center"
        }}
      >
        <Board
          board={board}
          selectedSquare={selectedSquare}
          legalMoves={legalMoves}
          onSquareClick={handleSquareClick}
        />
        <MoveHistory moves={moves} />
      </div>

      <TurnIndicator turn={turn} />
      {gameStatus && <div style={{ textAlign: "center" }}>{gameStatus}</div>}
    </div>
  );
}
